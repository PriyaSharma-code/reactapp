'use strict';

jest.dontMock('../../../common/components/App.js');

describe('App', function () {

  beforeEach(function () {
  });

  it('should create a new instance of App', function () {
  });
});
